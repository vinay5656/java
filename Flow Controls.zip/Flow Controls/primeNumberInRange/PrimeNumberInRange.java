package primeNumberInRange;

public class PrimeNumberInRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=10;i<=99;i++) {
			int number = i;
			boolean flag = true;
	        for(int j=2;j<number;j++) {
	        	if(number%j==0) {
	        		flag = false;
	        	}
	        }
	        if(flag == true) {
	        	System.out.println(number+" is a prime number");
	        }
	    
		}
	     return;

	}

}
