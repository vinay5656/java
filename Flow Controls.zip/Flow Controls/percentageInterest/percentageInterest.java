package percentageInterest;
import java.util.Scanner;
public class percentageInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		String gender = scanner.nextLine();
		int age = scanner.nextInt();
		if((gender=="Female") && (age>=1 && age<=58)) {
			System.out.println("Percentage of interest 8.2%");
		}else if((gender=="Female")&&(age>=59 && age<=100)) {
			System.out.println("Percentage of interest 9.2%");
		}else if((gender=="Male")&&(age>=1 && age<=58)) {
			System.out.println("Percentage of interest 8.4%");
		}else if((gender=="Male")&&(age>=59 && age<=100)){
			System.out.println("Percentage of interest 10.5%");
		}
		scanner.close();
		return;

	}

}
