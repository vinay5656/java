package checkPalindrome;

import java.util.Scanner;

public class CheckPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		long number = scanner.nextLong();
		long orignalNumber = number;
		long reverseNumber = 0;
		while(number>0) {
			reverseNumber = reverseNumber*10+number%10;
			number/=10;
		}
		if(orignalNumber == reverseNumber) {
			System.out.println(orignalNumber+" is a palindrome number");
		}else {
			System.out.println(orignalNumber+" is not a palindrome number");
		}
		scanner.close();
		return;

	}

}
