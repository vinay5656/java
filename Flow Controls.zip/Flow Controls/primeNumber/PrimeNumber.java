package primeNumber;
import java.util.Scanner;
public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        boolean flag = true;
        for(int i=2;i<number;i++) {
        	if(number%i==0) {
        		flag = false;
        	}
        }
        if(flag == true) {
        	System.out.println(number+" is a prime number");
        }else {
        	System.out.println(number+" is not a prime number");
        }
        scanner.close();
        return;
	}

}
