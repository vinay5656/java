package ltoUAndUToL;
import java.util.Scanner;

public class LToUAndUToL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		char anyChar = scanner.next().charAt(0);
	    if(anyChar>=65 && anyChar<=90) {
	         int num = anyChar-65;
	    	char lowerChar = (char)(num+97);
	    	System.out.println(anyChar+"->"+lowerChar);
	    }else if(anyChar>=97 && anyChar<=122) {
	    	int num = anyChar-97;
	        char upperChar = (char)(num+65);
	    	System.out.println(anyChar+"->"+upperChar);
	    }
		scanner.close();

	}

}
