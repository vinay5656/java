package sumOfDigit;
import java.util.Scanner;

public class SumOfDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        long number = scanner.nextLong();
        long sum = 0;
        while(number>0) {
        	sum+=number%10;
        	number/=10;
        }
        System.out.println("sum = "+sum);
        scanner.close();
	}

}
