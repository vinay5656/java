package sumOfTwoNumbers;
import java.util.Scanner;
public class SumOfTwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int firstNumber = scanner.nextInt();
		int secondNumber = scanner.nextInt();
		int sum = firstNumber+secondNumber;
		System.out.println("The sum of "+firstNumber+" or "+secondNumber+" is "+sum);
		scanner.close();
		return;

	}

}
