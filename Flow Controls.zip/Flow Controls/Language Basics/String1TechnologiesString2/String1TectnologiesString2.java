import java.util.Scanner;
public class String1TectnologiesString2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		String string1 = scanner.nextLine();
		String string2 = scanner.nextLine();
		System.out.println(string1+" Technologies "+ string2);
		scanner.close();
        return;
	}

}
