package reverseNumber;
import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		long number = scanner.nextLong();
		long reverseNumber = 0;
		while(number>0) {
			reverseNumber = reverseNumber*10+number%10;
			number/=10;
		}
		System.out.println("Reverse of Number: "+reverseNumber);
		scanner.close();
		return;

	}

}
