package TwoCharacterCampare;
import java.util.Scanner;

public class TwoCharacterCampare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		char firstCharacter = scanner.next().charAt(0);
		char secondCharacter = scanner.next().charAt(0);
		if(firstCharacter<=secondCharacter) {
			System.out.println(firstCharacter+", "+secondCharacter);
		}else {
			System.out.println(secondCharacter+", "+firstCharacter);
		}
		scanner.close();
		return;
	}

}
