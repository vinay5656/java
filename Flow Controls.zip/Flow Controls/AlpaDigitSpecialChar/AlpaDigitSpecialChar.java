package AlpaDigitSpecialChar;
import java.util.Scanner;
public class AlpaDigitSpecialChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        char unknownChar = scanner.next().charAt(0);
        int ascciValue = unknownChar;
        if(ascciValue>=48 && ascciValue<=57) {
        	System.out.println("Digit");
        }else if((ascciValue>=65 && ascciValue<=90)||(ascciValue>=97 && ascciValue<=122)) {
        	System.out.println("Alphabhet");
        }else {
        	System.out.println("Special Character");
        }
        scanner.close();
	}

}
