package forLoop;
//import java.util.Scanner;
public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner scanner = new Scanner(System.in);
		for(int i=1;i<=10;i++) {
			System.out.print(i+" ");
		}
        return;
	}

}
