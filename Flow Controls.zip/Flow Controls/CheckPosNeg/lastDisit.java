package CheckPosNeg;
import java.util.Scanner;
public class lastDisit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int firstNumber = scanner.nextInt();
		int secondNumber = scanner.nextInt();
		int fNlastDigit = firstNumber%10;
		int sNlastDigit = secondNumber%10;
		if(fNlastDigit == sNlastDigit) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
		scanner.close();
		return;

	}

}
