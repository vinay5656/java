package ReceiveCommandLineArgs;

public class ReceiveCommandLineArgs {
    
	public static void main(String[] args) {
		// For getting the command line args use this processor( Run->Run Config->Arguments->Program Args )
	    if(args.length==0) {
	    	System.out.println("No values");
	    }else {
	    	for(int i=0;i<args.length-1;i++) {
	    		System.out.println(args[i]+", ");
	    	}
	    	System.out.println(args[args.length-1]);
	    }
		return;

	}

}
