package welcomeMessage;
import java.util.Scanner;

public class WelcomeMessage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		String string1 = scanner.nextLine();
		System.out.println("Welcome "+string1);
		scanner.close();
		return;

	}

}
