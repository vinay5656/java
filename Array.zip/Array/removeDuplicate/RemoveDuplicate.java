package removeDuplicate;

import java.util.Scanner;

public class RemoveDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		int [] arr = new int[size];
		for(int i=0;i<size;i++) {
			arr[i] = scanner.nextInt();
		}
		for(int i=0;i<size-1;i++) {
			for(int j=1;j<size;j++) {
				if(arr[j-1]>arr[j]) {
					int temp = arr[j-1];
					arr[j-1]=arr[j];
					arr[j] = temp;
				}
			}
		}
        for(int i=0;i<size-1;i++) {
        	if(arr[i]==arr[i+1]) {
        		arr[i]=-1;
        	}
        }
        int count = 0;
        for(int i=0;i<size;i++) {
        	if(arr[i]==-1) {
        		continue;
        	}
        	count++;
        }
        int newArr[] = new int[count];
        int j=0;
        for(int i=0;i<size;i++) {
        	if(arr[i]==-1) {
        		continue;
        	}
        	newArr[j++] = arr[i];
        }
        for(int i=0;i<count;i++) {
        	System.out.print(newArr[i]+" ");
        }
        scanner.close();
        return;

	}

}
