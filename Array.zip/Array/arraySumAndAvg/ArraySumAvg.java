package arraySumAndAvg;
import java.util.Scanner;

public class ArraySumAvg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		int [] arr = new int[size];
		for(int i=0;i<size;i++) {
			arr[i] = scanner.nextInt();
		}
		int sum =0;
		for(int i=0;i<size;i++) {
			sum = sum+arr[i];
		}
		float avg = (float)sum/size;
		System.out.println("sum = "+sum+" average = "+avg);
		
		scanner.close();

	}

}
