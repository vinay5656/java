package biggestNum2DArr;

import java.util.Scanner;

public class BiggestNum2DArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

		int [][] arr = new int[3][3];
		int count = 0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				arr[i][j] = scanner.nextInt();
				count++;
			}	
		}
		if(count!=9) {
			System.out.println("Please enter 9 integer");
			scanner.close();
			return;
		}
		System.out.println("The given array is ");
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
		       System.out.print(arr[i][j]+" ");
			}
			System.out.println("");
		}
		int max = 0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
		       if(max<arr[i][j]) {
		    	   max= arr[i][j];
		       }
			}
		}
		System.out.print("The biggest number in the given array is " );
		System.out.println(max);
		scanner.close();
		return;

	}

}
