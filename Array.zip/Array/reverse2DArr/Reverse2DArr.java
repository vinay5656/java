package reverse2DArr;

import java.util.Scanner;

public class Reverse2DArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int row = scanner.nextInt();
		int col = scanner.nextInt();
		int [][] arr = new int[row][col];
		int count = 0;
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				arr[i][j] = scanner.nextInt();
				count++;
				
			}	
		}
		if(count!=4) {
			System.out.println("Please enter 4 integer");
			scanner.close();
			return;
		}
		System.out.println("The given array is ");
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
		       System.out.print(arr[i][j]+" ");
			}
			System.out.println("");
		}
		int temp=arr[0][0];
		arr[0][0] = arr[1][1];
		arr[1][1] = temp;
	    temp=arr[0][1];
		arr[0][1] = arr[1][0];
		arr[1][0] = temp;
		System.out.println("The reverse of the array is ");
		for(int i=0;i<row;i++) {
			for(int j=0;j<col;j++) {
				System.out.print(arr[i][j]+" ");
			}	
			System.out.println("");
		}
        scanner.close();
	    }

}
