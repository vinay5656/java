package arrSixSevenSum;

import java.util.Scanner;

public class ArrSixSevenSum {
	private static int find(int arr[],int givenNumber) {
    	int index = -1;
		for(int i=0;i<arr.length;i++) {
			if(givenNumber==arr[i]) {
				index = i;
			}
		}
		return index;
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		int [] arr = new int[size];
		for(int i=0;i<size;i++) {
			arr[i] = scanner.nextInt();
		}
		int indexOfSix = find(arr,6);
		int indexOfSeven = find(arr,7);
		boolean flag = false;
		if(indexOfSix<indexOfSeven) {
			flag = true;
		}
		int sum=0;
		for(int i=0;i<size;i++) {
			if(flag==true && (i>=indexOfSix && i<=indexOfSeven)) {
				continue;
			}
			sum =sum+arr[i];
		}
		System.out.print("SUM = "+sum);
		scanner.close();
        return;
	}

}
