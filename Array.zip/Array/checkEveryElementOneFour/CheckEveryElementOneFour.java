package checkEveryElementOneFour;

import java.util.Scanner;

public class CheckEveryElementOneFour {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		int [] arr = new int[size];
		for(int i=0;i<size;i++) {
			arr[i] = scanner.nextInt();
		}
		boolean flag = true;
		for(int i=0;i<size;i++) {
			if(arr[i]==1 ||arr[i]==4) {
				continue;
			}else {
				flag = false;
			}
		}
		if(flag==true) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
		scanner.close();
		return;

	}

}
