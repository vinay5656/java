package findNumArr;

import java.util.Scanner;

public class FindNUmInArr {
    private static int find(int arr[],int givenNumber) {
    	int index = -1;
		for(int i=0;i<arr.length;i++) {
			if(givenNumber==arr[i]) {
				index = i;
			}
		}
		return index;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		int [] arr = new int[size];
		for(int i=0;i<size;i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println("Enter a number : ");
		int givenNumber = scanner.nextInt();
//		int index = -1;
//		for(int i=0;i<size;i++) {
//			if(givenNumber==arr[i]) {
//				index = i;
//			}
//		}
		int index = find(arr,givenNumber);
		System.out.println("index = "+index);

		
		scanner.close();
	}

}
