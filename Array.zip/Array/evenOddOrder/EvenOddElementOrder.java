package evenOddOrder;

import java.util.Scanner;

public class EvenOddElementOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int size = scanner.nextInt();
		int [] arr = new int[size];
		for(int i=0;i<size;i++) {
			arr[i] = scanner.nextInt();
		}
		int [] newArr = new int[size];
		int evenIndex = 0;
		int oddIndex = size-1;
		for(int i=0;i<size;i++) {
			if(arr[i]%2==0) {
				newArr[evenIndex]=arr[i];
				evenIndex++;
				
			}else {
				newArr[oddIndex]=arr[i];
				--oddIndex;
			}
		}
		
        for(int i=0;i<size;i++) {
        	System.out.print(newArr[i]+" ");
		}
        scanner.close();
		

	}

}
