package music.wind;

import music.Playable;

public class Saxophone implements Playable{

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Saxophone");
	}

}
