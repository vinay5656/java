package music;

public interface Playable {
	void play();
}
