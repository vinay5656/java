package NumberFormatException;
import java.lang.System;
public class MyExceptionClass {
	int number;
	
	MyExceptionClass(int number){
		this.number = number;
	}
	
	public void generateException() {
		if(number>=0 && number<=100) {
			System.out.println("Good TO Go");
		}else {
			System.out.println("MyExceptionClass.NumberNotInRange");
			System.exit(0);
		}
	}
}
