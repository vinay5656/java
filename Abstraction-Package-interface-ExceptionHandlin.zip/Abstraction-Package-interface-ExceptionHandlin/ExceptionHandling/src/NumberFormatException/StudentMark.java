package NumberFormatException;

public class StudentMark {
	
    private String name;
    private int [] marks;
    
    StudentMark(String name, int firstSubjectMark, int secondSubjectMark, int thirdSubjectMark){
    	this.name = name;
    	marks = new int[3];
    	marks[0] = firstSubjectMark;
    	marks[1] = secondSubjectMark;
    	marks[2] = thirdSubjectMark;
    }
    public int totalMarks() {
        int num =0;
    	for(int i=0;i<3;i++) {
    		num = num+marks[i];
    	}
    	System.out.println("Total marks of "+ name + " :"+num);
    	return num;
    }
}
