package NumberFormatException;

import java.util.Scanner;

public class mainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		String firstStudentName = scanner.nextLine();
		String secondStudentName = scanner.nextLine();
		int firstStudentMarks[]= new int[3];
		for(int i=0;i<3;i++) {
			try {
				firstStudentMarks[i] = Integer.parseInt(scanner.next());
				MyExceptionClass obj = new MyExceptionClass(firstStudentMarks[i]);
				obj.generateException();
				}catch(Exception e) {
					System.out.println(e.toString());
				}
		}
		
		StudentMark s1 = new StudentMark(firstStudentName,firstStudentMarks[0],firstStudentMarks[1],firstStudentMarks[2]);
		int totalMarksOfS1 = s1.totalMarks();
		
		int secondStudentMarks[]= new int[3];
		for(int i=0;i<3;i++) {
			try {
				secondStudentMarks[i] = Integer.parseInt(scanner.next());
				}catch(Exception e) {
					System.out.println(e.toString());
				}
		}
		
		StudentMark s2 = new StudentMark(secondStudentName,secondStudentMarks[0],secondStudentMarks[1],secondStudentMarks[2]);
		int totalMarksOfS2 = s2.totalMarks();
		
		double averageMarks = totalMarksOfS1 + totalMarksOfS2;
		System.out.println("Average Mark's of two student "+averageMarks);
		
		scanner.close();

	}

}
