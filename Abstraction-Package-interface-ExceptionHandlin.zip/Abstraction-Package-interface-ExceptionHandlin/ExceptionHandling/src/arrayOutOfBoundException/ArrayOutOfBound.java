package arrayOutOfBoundException;

import java.util.Scanner;

public class ArrayOutOfBound {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of element in the array ");
        int size = scanner.nextInt();
        int arr[] = new int[size];
        
        System.out.println("Enter the element in the array");
        for(int i = 0; i < size; i++) {
        	try {
        		arr[i] = scanner.nextInt();
        	}catch(Exception e) {
        		System.out.println(e.toString());
        		System.exit(0);
        	}
        	
        }
        
        System.out.println("Enter the index of the array element you want to access");
        int requiredIndex = scanner.nextInt();
        
        try {
        	System.out.println("The array element at index "+requiredIndex+" = "+arr[requiredIndex]);
        	System.out.println("The array element successfully accessed");
        }catch(Exception e){
        	//System.out.println(e.getMessage());
//            e.printStackTrace();
        	System.out.println(e.toString());
        	//System.out.println(e.getCause());
        	//System.out.println(e.getLocalizedMessage());
            System.exit(0);
        }finally {
        	System.out.println("Thank's for using our services");
        }
      
        scanner.close();
	}

}
