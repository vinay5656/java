package person;

import java.util.Scanner;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		String name = scanner.nextLine();
		int age = scanner.nextInt();
		MyExceptionClass obj = new MyExceptionClass();
		boolean check  = obj.throwException(age);
		if(check==false) {
			System.exit(0);
		}
		Person p1 = new Person(age,name);
		p1.detail();
		
		scanner.close();

	}

}
