package person;

public class MyExceptionClass {
	public boolean throwException(int age) {
		if(age<=18 && age>=60) {
		    return true;
		}else {
			return false;
		}
	}

}
