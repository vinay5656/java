package person;

public class Person {
	private int age;
	private String name;
	
	Person(int age, String name){
	
		this.age = age;
		this.name = name;
	}
	
	public void detail() {
		System.out.println("Name :"+name);
		System.out.println("Age :"+age);
	}

}
