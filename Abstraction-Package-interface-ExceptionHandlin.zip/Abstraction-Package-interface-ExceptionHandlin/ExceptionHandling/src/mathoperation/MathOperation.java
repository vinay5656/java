package mathoperation;

import java.math.BigDecimal;
import java.util.Scanner;

public class MathOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		int arr[] = new int[5];
		for(int i=0;i<5;i++) {
			try {
				System.out.println("Enter the "+(i+1)+" number");
				arr[i] = scanner.nextInt();
			}catch(Exception e) {
				System.out.println(e.toString());
				System.exit(i+1);
			}
		}

		BigDecimal sum = new BigDecimal(0);
		BigDecimal divisor = new BigDecimal(5);
		for(int i=0 ; i<5; i++) {
			try {
				sum=sum.add(new BigDecimal(arr[i]));
			}catch(Exception e) {
				System.out.println(e.toString());
				System.exit(0);
			}
			
		}
		
		System.out.println("Sum = "+sum);
		
		try {
			
			BigDecimal average = sum.divide(divisor);
			System.out.println("Average = "+average);
		}catch(Exception e) {
		
			
		}
		scanner.close();

	}

}
