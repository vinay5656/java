package studentPortal;

public class UserRegistration {

	public void registerUser(String username,String userCountry) {
		InvalidCountryException test = new InvalidCountryException("india");
		boolean exception = test.trowException(userCountry);
		if(exception != true) {
			System.out.println("User registration done successfully");
		}else {
			System.out.println("User Outside India cannot be registered");
		}		
	}
}
