package studentPortal;

public class InvalidCountryException {
	
	private String country;
	
	InvalidCountryException(String country){
		this.country = "india";
	}
	
	public boolean trowException(String countryName) {
		if(country.equals(countryName)) {
			return false;
		}else {
			return true;
		}

	}

}
