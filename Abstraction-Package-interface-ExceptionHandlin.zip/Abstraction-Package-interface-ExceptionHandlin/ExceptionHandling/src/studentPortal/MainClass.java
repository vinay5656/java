package studentPortal;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
	    String username = scanner.nextLine();
	    String country = scanner.nextLine();
		
		UserRegistration process = new UserRegistration();
		process.registerUser(username, country);
	    scanner.close();

	}

}
