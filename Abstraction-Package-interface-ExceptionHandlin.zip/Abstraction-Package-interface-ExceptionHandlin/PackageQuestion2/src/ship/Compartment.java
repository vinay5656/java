package ship;

public class Compartment {
	int breadth;
	int height;
	int width;
	
 /*
  * I have create all data member with default type
  * so it won't conflict with any other class 
  * outside the ship package
  */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Compartment compartemt = new Compartment();
		compartemt.breadth = 800;
		compartemt.height =600;
		compartemt.width = 300;
		
		System.out.println(compartemt.breadth);
		System.out.println(compartemt.height);
		System.out.println(compartemt.width);

	}

}
