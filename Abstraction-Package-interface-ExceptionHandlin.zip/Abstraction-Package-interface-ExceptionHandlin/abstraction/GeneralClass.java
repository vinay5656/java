package abstraction;

public class GeneralClass extends Compartment{

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		System.out.println("It is suitable for General Class");
		return null;
	}

}
