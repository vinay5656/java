package abstraction;

public class LadiesClass extends Compartment{

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		System.out.println("It is suitable for Ladies Class");
		return null;
	}

}
