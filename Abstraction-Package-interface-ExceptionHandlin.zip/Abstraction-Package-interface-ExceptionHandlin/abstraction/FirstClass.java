package abstraction;

public class FirstClass extends Compartment{

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		System.out.println("It is suitable for First Class");
		return null;
	}

}
