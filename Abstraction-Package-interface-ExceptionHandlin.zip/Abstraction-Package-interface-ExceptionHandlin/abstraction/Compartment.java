package abstraction;

public abstract class Compartment {
	public abstract String notice();
}
