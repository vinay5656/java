package abstraction;

public class luggage extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		System.out.println("It is suitable for luggage Class");
		return null;		
	}

}
