package abstraction;

public class TestCompartment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Compartment []arr = new Compartment[10];
		
		FirstClass firstClass = new FirstClass();
	    arr[0] =  firstClass;
	    
	    LadiesClass ladiesClass = new LadiesClass();
	    arr[1]= ladiesClass;
	    
        luggage luggageObj = new luggage();
        arr[2] = luggageObj;
        
        GeneralClass generalClass = new GeneralClass();
        arr[3] = generalClass;
        
        Compartment compartment = arr[(int)(Math.random()*4)];
        compartment.notice();
        
	}

}
