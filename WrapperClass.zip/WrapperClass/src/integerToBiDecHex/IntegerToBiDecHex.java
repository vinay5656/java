package integerToBiDecHex;

import java.util.Scanner;

public class IntegerToBiDecHex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		System.out.println("Given Number :"+num);
		/* 
		 * Auto Boxing
		 * Integer number = num;
		 */
		
		String binaryRepresentation = Integer.toBinaryString(num);
		System.out.println("Binary Representation "+binaryRepresentation);
		
		String decimalRepresentation = Integer.toOctalString(num);
		System.out.println("Decimal Representation "+decimalRepresentation);
		
		String hexadecimalRepresentation = Integer.toHexString(num);
		System.out.println("Hexadecimal Representation "+hexadecimalRepresentation);
		
		
		scanner.close();

	}

}
