package cloning;

public class Employee {
    public int empId;
    public String empName;
    Employee(int empId,String empName){
    	this.empId = empId;
    	this.empName = empName;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Employee emp = new Employee(101803296, "Vinay");
        /*
         * it will create a copy of the reference variable and not the object.
         */
        Employee empClone = emp;
        emp.empName = "ravi";
        System.out.println("EmpName "+emp.empName+" EmpId "+emp.empId);
        System.out.println("EmpName "+empClone.empName+" EmpId "+empClone.empId);
	}

}
