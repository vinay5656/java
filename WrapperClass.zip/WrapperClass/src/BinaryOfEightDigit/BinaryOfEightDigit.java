package BinaryOfEightDigit;

import java.util.Scanner;

public class BinaryOfEightDigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        
        String binaryRepresentation = Integer.toBinaryString(num);
       
        int len = binaryRepresentation.length(); 
       
        if(len==8) {
        	System.out.println(binaryRepresentation);
        }else {
        	for(int i=len+1;i<=8;i++) {
        		binaryRepresentation="0"+binaryRepresentation;
        	}
        	System.out.println(binaryRepresentation);
        }
        scanner.close();
        
	}

}
