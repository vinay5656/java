package minmaxForEachType;

public class MinMaxOfTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Byte minByte = Byte.MIN_VALUE;
		Byte maxByte = Byte.MAX_VALUE;
	    System.out.println("Byte "+minByte+", "+maxByte);
		
		Short minShort = Short.MIN_VALUE;
		Short maxShort = Short.MAX_VALUE;
		System.out.println("Short "+minShort+", "+maxShort);
		
		Integer minInt = Integer.MIN_VALUE;
		Integer maxInt = Integer.MAX_VALUE;
		System.out.println("Integer "+minInt+", "+maxInt);
		
		Long minLong = Long.MIN_VALUE;
		Long maxLong = Long.MAX_VALUE;
		System.out.println("Long "+minLong+", "+maxLong);
		
		Double minDouble = Double.MIN_VALUE;
		Double maxDouble = Double.MAX_VALUE;
		System.out.println("Double "+minDouble+", "+maxDouble);
		
		Float minFloat = Float.MIN_VALUE;
		Float maxFloat = Float.MAX_VALUE;
		System.out.println("Float "+minFloat+", "+maxFloat);
		
		Character minChar = Character.MIN_VALUE;
		Character maxChar = Character.MAX_VALUE;
		System.out.println("Character "+minChar+", "+maxChar);
		
		return;

	}

}
