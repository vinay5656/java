package encapsulationAbtraction;

import java.util.Scanner;

public class BookMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the book Author name :");
		String name = scanner.nextLine();
		
		System.out.println("Enter the Author's email :");
		String email = scanner.nextLine();
		
		System.out.println("Enter the Author's gender :");
		char gender = scanner.nextLine().charAt(0);
		 
		System.out.println("Enter the book name :");
		String bookName = scanner.nextLine();
		
		System.out.println("Enter the book's price :");
		double price =scanner.nextDouble();
		
		System.out.println("Enter the book's qtyInStock :");
	    int qtyInStock = scanner.nextInt();
		
		BookClass book = new BookClass(name, email, gender, bookName, price, qtyInStock);
		
		book.getName();
		book.getEmail();
		book.getGender();
		book.getBookName();
		book.getPrice();
		book.getQtyInStock();
		
		scanner.close();

	}

}
