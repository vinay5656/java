package encapsulationAbtraction;

public class BookClass extends AuthorClass{
	
	private String bookName;
	private double price;
	private int qtyInStock;
	
	BookClass(String name, String email, char gender, String bookName, double price, int qtyInStock){
		
		super(name, email, gender);
		
		this.bookName = bookName;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}

	public void getBookName() {
		System.out.println("Name of the book is "+bookName);
		return;
	}

	public void getPrice() {
		System.out.println("price of the book is "+price);
		return;
	}

	public void getQtyInStock() {
	    System.out.println("Quatity of the book's is present in stock : "+qtyInStock);
		return;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
	
	

}
