package encapsulationAbtraction;

public class AuthorClass {
	
	private String email;
	private char gender;
	private String name;
	
	AuthorClass(String name, String email, char gender){
		this.email = email;
		this.gender = gender;
		this.name = name;
	}

	public void getEmail() {
		System.out.println("Author's Email :"+email);
		return;
	}

	public void getGender() {
		System.out.println("Gender :"+gender);
		return;
	}

	public void getName() {
		System.out.println("Author of the book :"+name);
		return;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public void setName(String name) {
		this.name = name;
	}

}
