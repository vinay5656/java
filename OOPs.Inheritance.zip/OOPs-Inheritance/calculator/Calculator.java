package calculator;

public class Calculator {
	
	Calculator(){}
	
	public static void powerInt(int base, int order) {
		double result = Math.pow(base, order);
		System.out.println("Result for the powerInt method :"+result);
		return;
	}
	
	public static void powerDouble(double base, double order) {
		double result = Math.pow(base, order);
		System.out.println("Result for the powerDouble method :"+result);
		return;
	}
}
