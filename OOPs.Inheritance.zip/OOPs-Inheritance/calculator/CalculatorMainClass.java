package calculator;

import java.util.Scanner;

public class CalculatorMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter base and order for powerInt method :");
        int base = scanner.nextInt();
        int order = scanner.nextInt();
  
        Calculator.powerInt(base, order);
        
        System.out.println("Enter base and order for powerDouble method :");
        double baseD = scanner.nextDouble();
        double orderD = scanner.nextDouble();
        
        Calculator.powerDouble(baseD, orderD);
        
        scanner.close();
	}

}
