package stringQuestions;

import java.util.Scanner;

public class EvenStrLen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		String inputString = scanner.nextLine();
		int stringLength = inputString.length();
		
		if(stringLength%2==0) {
			System.out.println(inputString.substring(0,stringLength/2));
		}else {
			System.out.println("null");
		}
		scanner.close();

	}

}
