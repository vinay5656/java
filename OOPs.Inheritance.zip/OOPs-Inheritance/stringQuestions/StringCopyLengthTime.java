package stringQuestions;

import java.util.Scanner;

public class StringCopyLengthTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		String inputString = scanner.nextLine();
		int stringLength = inputString.length();
		
		StringBuffer result = new StringBuffer();
		
		for(int i=1;i<=stringLength;i++) {
			result.append(inputString.substring(0, 2));
		}
		
		System.out.println(result);
		
		scanner.close();

	}

}
