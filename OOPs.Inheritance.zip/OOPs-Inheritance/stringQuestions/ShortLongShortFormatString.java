package stringQuestions;

import java.util.Scanner;

public class ShortLongShortFormatString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		
		String firstString = scanner.nextLine();
		int LengthFirst =  firstString.length();
		
		String secondString = scanner.nextLine();
		int LengthSecond = secondString.length();
		
		String result = "";
		
		if(LengthFirst > LengthSecond) {
			result = secondString+firstString+secondString;
			System.out.println(result);
		}else {
			result = firstString+secondString+firstString;
			System.out.println(result);
		}
		scanner.close();
	}

}
