package stringQuestions;

import java.util.Scanner;

public class WithoutX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		
		String inputString = scanner.nextLine();
		int stringLength = inputString.length();
		
		String result ="";
		if(inputString.charAt(0)=='x' && inputString.charAt(stringLength-1)=='x') {
			result = inputString.substring(1,stringLength-1);
		}else if(inputString.charAt(0)=='x' && inputString.charAt(stringLength-1)!='x') {
			result = inputString.substring(1);
		}else if(inputString.charAt(0)!='x' && inputString.charAt(stringLength-1)=='x') {
			result = inputString.substring(0,stringLength-1);
		}else {
			result = inputString;
		}
		System.out.println(result);
		scanner.close();

	}

}
