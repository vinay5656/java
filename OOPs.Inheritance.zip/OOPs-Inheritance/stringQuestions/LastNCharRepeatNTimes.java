package stringQuestions;

import java.util.Scanner;

public class LastNCharRepeatNTimes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		
		String inputString = scanner.nextLine();
		int numberOfCharFromLast = scanner.nextInt();
		
		int stringLength = inputString.length();
		
	    String stringFromLast = inputString.substring(stringLength-numberOfCharFromLast);
	    
	    StringBuffer result = new StringBuffer();
	    
	    while(numberOfCharFromLast!=0) {
	    	result.append(stringFromLast);
	    	numberOfCharFromLast--;
	    }
		System.out.println(result);
        scanner.close();
	}

}
