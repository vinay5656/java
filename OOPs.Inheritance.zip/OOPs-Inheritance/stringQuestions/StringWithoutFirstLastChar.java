package stringQuestions;

import java.util.Scanner;

public class StringWithoutFirstLastChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		
		String inputString = scanner.nextLine();
		System.out.println(inputString.substring(1,inputString.length()-1));
		scanner.close();
	}

}
