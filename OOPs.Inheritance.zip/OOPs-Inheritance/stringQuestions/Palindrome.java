package stringQuestions;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		String anyString = scanner.nextLine();
		int j=anyString.length()-1;
		boolean flag = false;
		
		for(int i=0;i<anyString.length();) {
			if(i>j) {
				break;
			}
			if(anyString.charAt(i)==anyString.charAt(j)) {
				i++;
				j--;
				continue;
			}else {
				flag = true;
				break;
			}
		}
		if(flag == true) {
			System.out.println(anyString+" is not palindrome");
		}else {
			System.out.println(anyString+" is palindrome");
		}
		
		scanner.close();
		

	}

}
