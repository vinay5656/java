package stringQuestions;

import java.util.Scanner;

public class concatination {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		String firstString = scanner.nextLine();
		String secondString = scanner.nextLine();
		
		firstString = firstString.toLowerCase();
		secondString = secondString.toLowerCase();
		String result = "";
		System.out.println("Output using String :");
		if(firstString.charAt(firstString.length()-1) ==
				secondString.charAt(0)) {
			result = firstString+secondString.substring(1);
			
		}else {
			result = firstString+" "+secondString;
		}
		System.out.println(result);
		
		/* 
		 * We can get same result using StringBuffer.
		 * String Buffer are mutable
		 * We can perform append or insert type of operation in StringBuffer
		 * but in string we cannot.
		 */
		StringBuffer bufOfFirstString = new StringBuffer(firstString);
		StringBuffer bufOfSecondString = new StringBuffer(secondString);
		//bufOfFirstString.insert(0,'A');
		/*
		 * line 34 is clearly showing how we can change the string contant.
		 */
		System.out.println("");
	    System.out.println("OutPut using StringBuffer:");	
		if(bufOfFirstString.charAt(bufOfFirstString.length()-1)
				== bufOfSecondString.charAt(0)) {
			System.out.println(bufOfFirstString+bufOfSecondString.substring(1));
		}else {
			System.out.println(bufOfFirstString+" "+bufOfSecondString);
		}
		scanner.close();
		

	}

}
