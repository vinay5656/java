package stringQuestions;

import java.util.Scanner;

public class CombinationOfTwoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		
		String inputString1 = scanner.nextLine();
		int firstStringLength = inputString1.length();
		
		String inputString2 = scanner.nextLine();
		int secondStringLength = inputString2.length();
		
		StringBuffer result = new StringBuffer();
		if(firstStringLength>=secondStringLength) {
			for(int i=0;i<secondStringLength;i++) {
				result.append(inputString1.charAt(i));
				result.append(inputString2.charAt(i));
			}
			int i = secondStringLength;
			while(i!=firstStringLength) {
				result.append(inputString1.charAt(i));
				i++;
			}
		}else {
			for(int i=0;i<firstStringLength;i++) {
				result.append(inputString1.charAt(i));
				result.append(inputString2.charAt(i));
			}
			int i = firstStringLength;
			while(i!=secondStringLength) {
				result.append(inputString2.charAt(i));
				i++;
			}
			
		}
		System.out.println(result);
		
		scanner.close();

	}

}
