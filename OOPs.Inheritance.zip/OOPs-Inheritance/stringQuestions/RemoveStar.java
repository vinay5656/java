package stringQuestions;

import java.util.Scanner;

public class RemoveStar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
		
		String inputString = scanner.nextLine();
//	    int stringLength = inputString.length();
		
	    int indexOfStar = inputString.indexOf("*");
	    String result = inputString.substring(0,indexOfStar-1)+inputString.substring(indexOfStar+2);
	       
		System.out.println(result);
		scanner.close();
	}

}
