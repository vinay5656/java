package polymorphism;

public class Orange extends FruitClass{

	Orange(String fruitName, int size, String tasteType) {
		super("Orange", size, tasteType);
		// TODO Auto-generated constructor stub
	}
	public void eat() {
		System.out.println("Orange is "+tasteType+" in taste.");
	}

}
