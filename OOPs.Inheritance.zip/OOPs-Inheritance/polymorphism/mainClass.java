package polymorphism;

public class mainClass {
	public static void main(String []args) {
		
//		String appleFruit = "Apple";// We can do some changes in fruitName parameter
		String appleTasteType = "a little sweet and a little tart";
		int size = 10;
		
		Apple apple = new Apple("Apple", appleTasteType, size);
		apple.eat();
		
//		String orangeFruit = "Orange";// We can do some changes in fruitName parameter
		String orangeTasteType = "sweet-tart";
		int sizeOfOrange = 9;
		
		Orange orange = new Orange("Orange", sizeOfOrange, orangeTasteType);
		orange.eat();

		
	}

}
