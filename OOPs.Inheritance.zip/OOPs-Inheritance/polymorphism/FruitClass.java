package polymorphism;

public class FruitClass {
	String fruitName;
	String tasteType;
	int size;
	
	FruitClass(String fruitName, int size, String tasteType){
		this.fruitName = fruitName;
		this.size = size;
		this.tasteType = tasteType;
	}
	
	public void eat() {
		System.out.println(fruitName+" is "+tasteType+" in taste");
	}

}
