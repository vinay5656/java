package polymorphism;

public class Apple extends FruitClass{

	Apple(String fruitName, String tasteType, int size) {
		super("Apple", size, tasteType);
		// TODO Auto-generated constructor stub
	}
	
	public void eat() {
		System.out.println("Apple is "+tasteType+" in taste.");
	}
}
