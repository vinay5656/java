package polymorphismQ2;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//We are doing here up casting
		
		Shape circle = new Circle();
		//due to circle is also a shape
		
		Shape triangle = new Triangle();
		//due to triangle is also a shape
		
		Shape square = new Square();
		//due to square is also a shape
		
		/* 
		 * because we overriden the methos's draw() and erase()
		 * and done the up casting
		 * due to runtime polymophism calling will happen base on the type of the object
		 */
		circle.draw();
		triangle.draw();
		square.draw();
		
		circle.erase();
		triangle.erase();
		square.erase();

	}

}
