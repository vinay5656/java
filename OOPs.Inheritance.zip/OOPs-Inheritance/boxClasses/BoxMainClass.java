package boxClasses;

import java.util.Scanner;

public class BoxMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the depth of the box :");
		int depth = scanner.nextInt();
		System.out.println("Please enter the height of the box :");
		int height = scanner.nextInt();
		System.out.println("Please enter the width of the box :");
		int width = scanner.nextInt();
		BoxClass anyBox = new BoxClass(depth,height,width);
		long volume = anyBox.volume();
		System.out.println("Volume of the box : "+volume);
		scanner.close();

	}

}
