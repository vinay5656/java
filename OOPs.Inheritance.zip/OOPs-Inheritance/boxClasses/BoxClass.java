package boxClasses;

public class BoxClass {
	private int depth;
    private int height;
	private int width;
    BoxClass(int depth,int height,int width){
    	this.depth = depth;
    	this.height = height;
    	this.width = width;
    }
    public long volume() {
    	long boxVolume = depth * height * width;
    	return boxVolume;
    }
}
