package inheritanceQ2;

import java.util.Scanner;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter employee's details :");
		String name = scanner.nextLine();
		String insuranceNumber = scanner.nextLine();
		int joiningYear = scanner.nextInt();
		double annualSalary = scanner.nextDouble();
		
		Employee anyEmployee = new Employee(name, annualSalary, insuranceNumber, joiningYear);
		
		anyEmployee.getEmployeeName();
		anyEmployee.getInsuranceNumber();
		anyEmployee.getJoinYear();;
		anyEmployee.getAnnualSalary();;
		
		scanner.close();

	}

}
