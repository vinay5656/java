package inheritanceQ2;

public class Employee extends Person{
	
	double annualSalary;
	private String insuranceNumber;
	private int joiningYear;
	
	Employee(String name, double annualSalary, String insuranceNumber, int joiningYear){
		super(name);
		this.annualSalary = annualSalary;
		this.insuranceNumber = insuranceNumber;
		this.joiningYear = joiningYear;
	}
	
	public void getEmployeeName() {
		System.out.println("Employee Name :"+super.name);
		return;
	}
	
	public void getAnnualSalary() {
		System.out.println("Employee's Annual Salary :"+annualSalary);
	}
	
	public void getInsuranceNumber() {
		System.out.println("Insurance Number :"+insuranceNumber);
	}
	
	public void getJoinYear() {
		System.out.println("Joining Year :"+joiningYear);
	}

}
